package Sprzedaz;

import Magazyn.Produkt;
import Uzytkownicy.Osoba;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Zamowienie {
    Osoba uzykownik;
    List<Pozycja> pozycje;
    float kwota;
    Date data;

    public Zamowienie(Osoba uzykownik) {
        this.uzykownik = uzykownik;
        this.pozycje = new ArrayList<>();
        this.kwota = 0F;
        this.data = new Date();
    }

    public boolean dodajPozycje(Pozycja pozycja) {
        if (pozycja == null) return false;
        this.pozycje.add(new Pozycja(pozycja));
        this.kwota += pozycja.cenaBazowa;
        return true;
    }

    public boolean dodajProduktDoPozycji(Pozycja pozycja, Produkt produkt, float ilosc) {
        if (!this.pozycje.contains(pozycja) || pozycja == null || produkt == null) return false;
        pozycja.dodajProdukt(produkt, ilosc);
        this.kwota += ilosc * produkt.getCena();
        return true;
    }

    public Pozycja getPozycja(String nazwa){
        for (Pozycja pozycja : this.pozycje) {
            if (pozycja.nazwa.equals(nazwa)) return pozycja;
        }
        return null;
    }

    String pozycjeToString(){
        String s = "";
        for (Pozycja pozycja : this.pozycje) {
            s += "- " + pozycja.nazwa + " [";
            for (Produkt produkt : pozycja.produkty) {
                s += produkt.getNazwa() + ", ";
            }
            s += "\b\b]\n";
        }
        return s;
    }

    @Override
    public String toString() {
        return "Zamówienie [" + data + "]" +
                "\nUżykownik: " + uzykownik.getImie() + " " + uzykownik.getNazwisko() +
                "\nPozycje:\n" + pozycjeToString() +
                "Kwota: " + String.format("%.2f PLN\n", kwota);
    }

    public Osoba getUzykownik() {
        return uzykownik;
    }

    public void setUzykownik(Osoba uzykownik) {
        this.uzykownik = uzykownik;
    }

    public List<Pozycja> getPozycje() {
        return pozycje;
    }

    public void setPozycje(List<Pozycja> pozycje) {
        this.pozycje = pozycje;
    }

    public float getKwota() {
        return kwota;
    }

    public void setKwota(float kwota) {
        this.kwota = kwota;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
}

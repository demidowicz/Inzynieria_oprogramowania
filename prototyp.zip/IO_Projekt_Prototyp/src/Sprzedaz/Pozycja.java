package Sprzedaz;

import Magazyn.Produkt;

import java.util.ArrayList;
import java.util.List;

public class Pozycja {
    String nazwa;
    float cenaBazowa;
    public List<Produkt> produkty;

    public Pozycja(String nazwa, float cenaBazowa) {
        this.produkty = new ArrayList<>();
        this.nazwa = nazwa;
        this.cenaBazowa = cenaBazowa;
    }
    public Pozycja(Pozycja pozycja) {
        this.nazwa = pozycja.nazwa;
        this.cenaBazowa = pozycja.cenaBazowa;
        this.produkty = new ArrayList<>();
        this.produkty.addAll(pozycja.produkty);
    }

    public boolean dodajProdukt(Produkt produkt, float ilosc) {
        if (produkt == null) return false;
        this.produkty.add(produkt);
        this.cenaBazowa += ilosc * produkt.getCena();
        return true;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public float getCenaBazowa() {
        return cenaBazowa;
    }

    public void setCenaBazowa(float cenaBazowa) {
        this.cenaBazowa = cenaBazowa;
    }

    public List<Produkt> getProdukty() {
        return produkty;
    }

    public void setProdukty(List<Produkt> produkty) {
        this.produkty = produkty;
    }
}

import Magazyn.*;
import Sprzedaz.*;
import Uzytkownicy.*;

import java.util.ArrayList;
import java.util.List;

// prototyp obsługi magazynu i zamówień

public class Main {
    static List<Osoba> uzytkownicy = new ArrayList<>();
    static List<Pozycja> pozycje = new ArrayList<>();

    public static void main(String[] args) {
        dodajUzytkownikow(); // tworzy kilu uzytkownikow
        dodajProdukty(); // tworzy kilka produktow
        dodajPartie(); // tworzy kilka partii do tych produktow
        wyswieltStanMagazynu(); // wyswietla aktualny stan magazynu

        dodajPozycje(); // tworzy kilka pozycji
        // tworzenie zamowien, kwoty obliczane na podstawie sum bazowych cen pozycji + cen dodatkowych skladnikow
        stworzZamowienieStandardowe(); // tworzy zamowienie z jedna pozycja
        stworzZamowienieNiestandardowe(); // tworzy zamowienie z dwoma pozycjami z dodatkowymi skladnikami

    }

    private static void dodajUzytkownikow() {
        Osoba pracownik = new Pracownik("Jan", "Kowalski", "12345678910");
        uzytkownicy.add(pracownik);
        Osoba kierownik = new Kierownik("Szymon", "Kowalczyk", "12345678911");
        uzytkownicy.add(kierownik);
        Osoba szef = new Szef("Janusz", "Nowak", "12345678915");
        uzytkownicy.add(szef);
    }

    private static void dodajProdukty() {
        Magazyn.dodajProdukt("Chleb", 4.25f, true, true);
        Magazyn.dodajProdukt("Szynka", 21.5f, false, false);
        Magazyn.dodajProdukt("Pomidor", 22f, false, true);
        Magazyn.dodajProdukt("Ogórek", 2.95f, false, true);
        Magazyn.dodajProdukt("Ser", 62.34f, false, true);
    }

    private static void dodajPartie() {
        Magazyn.dodajPartieProduktu(Magazyn.getProdukt("Chleb"), 20.5F, "Piekarnia Adam");
        Magazyn.dodajPartieProduktu(Magazyn.getProdukt("Chleb"), 50.45F, "Piekarnia Pawełek");
        Magazyn.dodajPartieProduktu(Magazyn.getProdukt("Szynka"), 15.5F, "Rzeźnik");
        Magazyn.dodajPartieProduktu(Magazyn.getProdukt("Ser"), 35.5F, "Mleczarnia");
        Magazyn.dodajPartieProduktu(Magazyn.getProdukt("Ogórek"), 10F, "Farma");
        Magazyn.dodajPartieProduktu(Magazyn.getProdukt("Pomidor"), 12F, "Farma");
    }

    private static void wyswieltStanMagazynu() {
        System.out.println(Magazyn.stanToString());
    }

    private static void dodajPozycje() {
        Pozycja pozycja1 = new Pozycja("Kanapka z szynką", 20f);
        pozycja1.dodajProdukt(Magazyn.getProdukt("Chleb"), 0.8f);
        pozycja1.dodajProdukt(Magazyn.getProdukt("Szynka"), 0.072f);
        Pozycja pozycja2 = new Pozycja("Kanapka z serem", 21f);
        pozycja2.dodajProdukt(Magazyn.getProdukt("Chleb"), 0.2f);
        pozycja2.dodajProdukt(Magazyn.getProdukt("Ser"), 0.073f);
        pozycje.add(pozycja1);
        pozycje.add(pozycja2);
    }

    private static void stworzZamowienieStandardowe() {
        Zamowienie zamowienie = new Zamowienie(uzytkownicy.get(1));
        zamowienie.dodajPozycje(pozycje.get(0));
        System.out.println(zamowienie);
    }

    private static void stworzZamowienieNiestandardowe() {

        Zamowienie zamowienie = new Zamowienie(uzytkownicy.get(0));
        zamowienie.dodajPozycje(pozycje.get(0));
        zamowienie.dodajPozycje(pozycje.get(1));
        zamowienie.dodajProduktDoPozycji(zamowienie.getPozycja("Kanapka z szynką"), Magazyn.getProdukt("Ogórek"), 0.05f);
        zamowienie.dodajProduktDoPozycji(zamowienie.getPozycja("Kanapka z szynką"), Magazyn.getProdukt("Pomidor"), 0.05f);
        zamowienie.dodajProduktDoPozycji(zamowienie.getPozycja("Kanapka z serem"), Magazyn.getProdukt("Pomidor"), 0.05f);
        System.out.println(zamowienie);
    }
}
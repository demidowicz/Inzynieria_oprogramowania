package Uzytkownicy;

public class Pracownik extends Osoba {


    public Pracownik(String imie, String nazwisko, String pesel) {
        super(imie, nazwisko, pesel);
    }
}

package Uzytkownicy;

public class Szef extends Osoba{

    public Szef(String imie, String nazwisko, String pesel) {
        super(imie, nazwisko, pesel);
    }
}

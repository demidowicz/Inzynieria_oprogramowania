package Uzytkownicy;

public class Kierownik extends Osoba {

    public Kierownik(String imie, String nazwisko, String pesel) {
        super(imie, nazwisko, pesel);
    }
}

package Magazyn;

import java.util.ArrayList;
import java.util.List;

public class Magazyn {
    static List<Produkt> produkty;

    static {
        produkty = new ArrayList<>();
    }

    public static void dodajProdukt(String nazwa, float cena, boolean czyGluten, boolean czyWege) {
        Produkt nowyProdukt = new Produkt(nazwa, cena, czyGluten, czyWege);
        produkty.add(nowyProdukt);
    }

    public static boolean usunProdukt(Produkt produkt){
        return true;
    }

    public static boolean dodajPartieProduktu(Produkt produkt, float iloscPartia, String dostawca) {
        if (produkt == null || iloscPartia <= 0) return false;
        produkt.dodajPartie(iloscPartia, dostawca);
        return true; // produkt istnieje
    }

    public static boolean usunPartieProduktu(Produkt produkt) {
        return true;
    }

    public static Produkt getProdukt(String nazwaProdukt) {
        for (Produkt produkt : produkty) {
            if (produkt.nazwa.equals(nazwaProdukt)) {
                return produkt; // produkt istnieje
            }
        }
        return null; // produkt nie istnieje
    }

    public static float getIloscProduktow() {
        float suma = 0;
        for (Produkt produkt : produkty) {
            suma += produkt.getIlosc();
        }
        return suma;
    }

    public static float getIloscProduktu(String nazwaProdukt) {
        Produkt produkt = getProdukt(nazwaProdukt);
        if (produkt == null) return 0F;
        return produkt.getIlosc();
    }

    static String produktyToString() {
        String s = "";
        for (Produkt produkt : produkty) {
            s += "Produkt {" +
                    "\n  Nazwa: " + produkt.nazwa +
                    "\n  Cena sprzedaży: " + String.format("%.2f PLN/kg", produkt.cena) +
                    "\n  Łączna ilość: " + produkt.getIlosc() + "kg" +
                    "\n  Gluten: " + produkt.czyGluten +
                    "\n  Wege: " + produkt.czyWege +
                    "\n  Partie {";
            for (Partia partia : produkt.partie) {
                s += partia;
            }
            s += "\n  }\n }\n";
        }
        return s;
    }

    public static String stanToString() {
        return "### STAN MAGAZYNU ###" +
                "\nŁączna ilość produktów: " + getIloscProduktow() + "kg" +
                "\nProdukty:\n " + produktyToString() +
                "### KONIEC ###";
    }
}

package Magazyn;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Produkt {
    String nazwa;
    float cena; // cena za 1kg
    boolean czyGluten;
    boolean czyWege;
    List<Partia> partie;

    Produkt(String nazwa, float cena, boolean czyGluten, boolean czyWege) {
        this.nazwa = nazwa;
        this.cena = cena;
        this.czyGluten = czyGluten;
        this.czyWege = czyWege;
        this.partie = new ArrayList<>();
    }

    void dodajPartie(float iloscPartia, String dostawca) {
        Partia nowaPartia = new Partia(this, iloscPartia, new Date(), dostawca);
        this.partie.add(nowaPartia);
    }

    boolean usunPartie(Partia partia){
        return true;
    }

    public float getIlosc() {
        float suma = 0;
        for (Partia partia : this.partie) {
            suma += partia.ilosc;
        }
        return suma;
    }

    public String getNazwa() {
        return nazwa;
    }

    public float getCena() {
        return cena;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public void setCena(float cena) {
        this.cena = cena;
    }

    public boolean isCzyGluten() {
        return czyGluten;
    }

    public void setCzyGluten(boolean czyGluten) {
        this.czyGluten = czyGluten;
    }

    public boolean isCzyWege() {
        return czyWege;
    }

    public void setCzyWege(boolean czyWege) {
        this.czyWege = czyWege;
    }

    public List<Partia> getPartie() {
        return partie;
    }

    public void setPartie(List<Partia> partie) {
        this.partie = partie;
    }
}

package Magazyn;

import java.util.Date;

public class Partia {
    Produkt produkt;
    float ilosc;
    Date dataWaznosci;
    String dostawca;

    Partia(Produkt produkt, float ilosc, Date dataWaznosci, String dostawca) {
        this.produkt = produkt;
        this.ilosc = ilosc;
        this.dataWaznosci = dataWaznosci;
        this.dostawca = dostawca;
    }

    @Override
    public String toString() {
        return "\n   Ilość: " + ilosc + "kg" +
                "\n   Data ważnosci: " + dataWaznosci +
                "\n   Dostawca: " + dostawca;
    }

    public Produkt getProdukt() {
        return produkt;
    }

    public void setProdukt(Produkt produkt) {
        this.produkt = produkt;
    }

    public float getIlosc() {
        return ilosc;
    }

    public void setIlosc(float ilosc) {
        this.ilosc = ilosc;
    }

    public Date getDataWaznosci() {
        return dataWaznosci;
    }

    public void setDataWaznosci(Date dataWaznosci) {
        this.dataWaznosci = dataWaznosci;
    }

    public String getDostawca() {
        return dostawca;
    }

    public void setDostawca(String dostawca) {
        this.dostawca = dostawca;
    }
}

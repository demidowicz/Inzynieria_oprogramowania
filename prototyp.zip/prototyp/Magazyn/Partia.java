package Magazyn;

public class Partia {

	private string id;
	private Date data_waznosci;
	private int ilosc;
	private string dostawca;

}
package Magazyn;

import java.util.*;

public class Produkt {

	Collection<Partia> partie;
	private string id;
	private string nazwa;
	private int ilosc;
	private boolean czyGluten;
	private boolean czyWege;

}
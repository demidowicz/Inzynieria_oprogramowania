package Magazyn;

import java.util.*;

public class Magazyn {

	Collection<Produkt> produkty;
	private int ilosc_produktow;

}
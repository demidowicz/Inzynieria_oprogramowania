public interface Logowanie {
}
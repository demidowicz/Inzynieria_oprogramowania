package Osoba;

public class Raport {

	Kierownik autor;
	private Date data;
	private float utarg;

}
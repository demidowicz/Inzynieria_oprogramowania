package Osoba;

public class Osoba {

	private string imie;
	private string nazwisko;
	private string PESEL;
	private string login;
	private string haslo;

	public void wyswietlMagazyn() {
		// TODO - implement Osoba.wyswietlMagazyn
		throw new UnsupportedOperationException();
	}

	public void wyswietlPlatnosc() {
		// TODO - implement Osoba.wyswietlPlatnosc
		throw new UnsupportedOperationException();
	}

}
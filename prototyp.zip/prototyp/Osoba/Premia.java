package Osoba;

public class Premia {

	Pracownik pracownik;
	private float kwota;
	private Date data;

}
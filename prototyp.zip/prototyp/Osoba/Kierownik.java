package Osoba;

import java.util.*;

public class Kierownik extends Osoba {

	Collection<Raport> raporty;

	public boolean stworzRaport() {
		// TODO - implement Kierownik.stworzRaport
		throw new UnsupportedOperationException();
	}

	public void wyswietlPremie() {
		// TODO - implement Kierownik.wyswietlPremie
		throw new UnsupportedOperationException();
	}

	public void wyswietlRaport() {
		// TODO - implement Kierownik.wyswietlRaport
		throw new UnsupportedOperationException();
	}

}
package Osoba;

public class Szef extends Kierownik {

	public float obliczPremie() {
		// TODO - implement Szef.obliczPremie
		throw new UnsupportedOperationException();
	}

	public boolean rejestrujUzytkownika() {
		// TODO - implement Szef.rejestrujUzytkownika
		throw new UnsupportedOperationException();
	}

	public boolean usunUzytkownika() {
		// TODO - implement Szef.usunUzytkownika
		throw new UnsupportedOperationException();
	}

}
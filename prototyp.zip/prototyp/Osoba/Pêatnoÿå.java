package Osoba;

public class P�atno�� {

	Pracownik pracownik;
	private float kwota;
	private Date data;

}
package Osoba;

import java.util.*;

public class Pracownik extends Osoba {

	Collection<Premia> premie;
	Collection<P�atno��> platnosci;

	public boolean zapiszPlatnosc() {
		// TODO - implement Pracownik.zapiszPlatnosc
		throw new UnsupportedOperationException();
	}

	public boolean edytujMagazyn() {
		// TODO - implement Pracownik.edytujMagazyn
		throw new UnsupportedOperationException();
	}

}